Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/pn532_simpletest.py
    :caption: examples/pn532_simpletest.py
    :linenos:
