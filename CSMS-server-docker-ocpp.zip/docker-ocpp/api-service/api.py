from fastapi import FastAPI, Query
import aiomysql, os

app = FastAPI(title="OCPP API")

# Config dari docker-compose environment
DB_CONFIG = dict(
    host=os.getenv("DB_HOST", "localhost"),
    user=os.getenv("DB_USER", "ocppuser"),
    password=os.getenv("DB_PASS", "ocpppass"),
    db=os.getenv("DB_NAME", "ocpp"),
)

async def get_pool():
    return await aiomysql.create_pool(**DB_CONFIG)

@app.get("/cps")
async def get_cps():
    pool = await get_pool()
    result = []
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            # ambil charge points
            await cur.execute("SELECT * FROM charge_points")
            cps = await cur.fetchall()

            for cp in cps:
                cp_id = cp["id"]

                # total kWh dihitung dari transaksi
                await cur.execute("""
                    SELECT SUM(meter_stop - meter_start)/1000 AS total_kwh
                    FROM transactions
                    WHERE cp_id=%s AND meter_stop IS NOT NULL
                """, (cp_id,))
                total = await cur.fetchone()
                cp["total_kwh"] = total["total_kwh"] or 0

                # ambil connector per CP
                await cur.execute("""
                    SELECT connector_id, status, error_code, last_update as last_heartbeat
                    FROM connectors WHERE cp_id=%s
                """, (cp_id,))
                connectors = await cur.fetchall()
                cp["connectors"] = connectors

                result.append(cp)

    return result

@app.get("/connectors/{cp_id}")
async def get_connectors(cp_id: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute("SELECT * FROM connectors WHERE cp_id=%s", (cp_id,))
            return await cur.fetchall()

@app.get("/transactions")
async def get_transactions(page: int = Query(1, ge=1), limit: int = Query(5, ge=1, le=100)):
    pool = await get_pool()
    async with pool.acquire() as conn:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            offset = (page - 1) * limit
            await cur.execute("SELECT * FROM transactions ORDER BY id DESC LIMIT %s OFFSET %s", (limit, offset))
            rows = await cur.fetchall()
            return rows

