from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
import httpx
import os
from datetime import datetime

app = FastAPI()
templates = Jinja2Templates(directory="templates")

API_URL = os.getenv("API_URL", "http://api-service:8000")


@app.get("/")
async def dashboard(request: Request, page: int = 1, limit: int = 5):
    async with httpx.AsyncClient() as client:
        # Ambil charge points
        cps_resp = await client.get(f"{API_URL}/cps")
        cps = cps_resp.json()

        # Ambil transactions (dengan pagination)
        txs_resp = await client.get(f"{API_URL}/transactions", params={"page": page, "limit": limit})
        txs = txs_resp.json()

        # Ambil connectors per CP
        connectors_by_cp = {}
        for cp in cps:
            cp_id = cp["id"]
            try:
                resp = await client.get(f"{API_URL}/connectors/{cp_id}")
                if resp.status_code == 200:
                    connectors_by_cp[cp_id] = resp.json()
                else:
                    connectors_by_cp[cp_id] = []
            except Exception:
                connectors_by_cp[cp_id] = []

        # Format last_update di connectors
        for cp_id, conns in connectors_by_cp.items():
            for conn in conns:
                if conn.get("last_update"):
                    try:
                        conn["last_update"] = datetime.fromisoformat(conn["last_update"]).strftime("%Y-%m-%d %H:%M:%S")
                    except Exception:
                        pass

        # Format start/stop time di transactions
        for tx in txs:
            if tx.get("start_ts"):
                try:
                    tx["start_ts"] = datetime.fromisoformat(tx["start_ts"]).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass
            if tx.get("stop_ts"):
                try:
                    tx["stop_ts"] = datetime.fromisoformat(tx["stop_ts"]).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    pass

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "cps": cps,
        "connectors_by_cp": connectors_by_cp,
        "txs": txs,
        "page": page,
        "limit": limit
    })
